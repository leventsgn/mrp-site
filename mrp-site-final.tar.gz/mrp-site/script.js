/*
 * JavaScript interactions for MRP Solutions website
 * Handles mobile navigation toggling, scroll reveal animations,
 * dynamic year display in the footer and contact form submission via mailto.
 */

// Toggle mobile navigation
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.classList.toggle('active');
    });

    // Close the menu when a link is clicked (mobile)
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            hamburger.classList.remove('active');
        });
    });
}

// Update footer year
const yearSpan = document.getElementById('year');
if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
}

// Intersection Observer for scroll reveal
// Collect elements that should reveal on scroll.  
// In addition to the original components (features, benefits, about sections and contact),
// also watch any elements on subpages that use the `.feature-card` or `.detail-content` classes.
const revealElements = document.querySelectorAll(
    '.feature, .benefit, .about-text, .about-image, .contact-content, .feature-card, .detail-content'
);

const observerOptions = {
    threshold: 0.15
};

const revealOnIntersect = (entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('show');
            observer.unobserve(entry.target);
        }
    });
};

const observer = new IntersectionObserver(revealOnIntersect, observerOptions);

revealElements.forEach(element => {
    observer.observe(element);
});

// Contact form submission handler
const contactForm = document.getElementById('contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();
        const subject = encodeURIComponent('MRP Çözümü İletişim Formu');
        const body = encodeURIComponent(
            `Ad: ${name}\nEmail: ${email}\nMesaj: ${message}`
        );
        const mailtoLink = `mailto:info@mrpsolutions.com?subject=${subject}&body=${body}`;
        // Open user's default email client with prepopulated subject and body
        window.location.href = mailtoLink;
    });
}